// Selección de ciudad
document.querySelectorAll('.carrera-opcion').forEach(function(item) {
    item.addEventListener('click', function() {
        const carreraSeleccionada = this.textContent;
        const carreraInput = document.getElementById('carreraInput');
        
        carreraInput.value = carreraSeleccionada;
        carreraInput.classList.remove('input-seleccionado');
        carreraInput.classList.add('input-seleccionado');

        const collapse = bootstrap.Collapse.getInstance(document.getElementById('collapseCarreras'));
        if (collapse) {
            collapse.hide();
        }
    });
});

document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault();

    const form = this;
    const alerta = document.getElementById('alerta');

    if (form.checkValidity()) {
        // Ocultar la alerta si estaba visible
        alerta.classList.add('d-none');

        // Mostrar el modal
        const modal = new bootstrap.Modal(document.getElementById('modalInfo'));
        modal.show();
    } else {
        // Mostrar alerta visual de Bootstrap
        alerta.classList.remove('d-none');

        // Agregar clases visuales de validación de Bootstrap
        form.classList.add('was-validated');
    }
});

    // Contenido dinámico
    let modal = document.getElementById('modalInfo')

    modal.addEventListener('show.bs.modal', function(event){
    let boton = event.relatedTarget
    console.log(boton.getAttribute('data-bs-encabezado'))
    
    document.querySelector('.modal-body').innerHTML = boton.getAttribute('data-bs-encabezado')
    document.querySelector('.modal-title').textContent = boton.getAttribute('data-bs-titulo')
    
    let modalHeader = document.querySelector('.modal-header')
    modalHeader.classList.add('text-white')
    modalHeader.classList.add(boton.getAttribute('data-bs-clase'))
})

    // Toast 
    window.addEventListener('DOMContentLoaded', () => {
    const toastElement = document.getElementById('miToast');
    const toast = new bootstrap.Toast(toastElement);

    setTimeout(() => {
      toast.show();
    }, 3000); 
  });










